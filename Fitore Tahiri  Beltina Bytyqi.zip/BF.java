public class BF
{private double d;
   private double v;
   private double a;
   public static double bf1(double v,double a)
   { double d = v*+(1.0/2.0)*a*0*0;
      return d;
   }
   public static double bf2(double v,double a)
   {double d = v*1+(1.0/2.0)*a*1*1; 
      return d;
   }
   public static double bf3(double v,double a)
   {double d = v*2+(1.0/2.0)*a*2*2; 
      return d;
   }
   public static double bf4(double v,double a)
   {double d = v*3+(1.0/2.0)*a*3*3; 
      return d;
   }
   public static double bf5(double v,double a)
   {double d = v*4+(1.0/2.0)*a*4*4; 
      return d;
   }
   public static double  bf6(double v,double a)
   {double d = v*5+(1.0/2.0)*a*5*5; 
      return d;
   
   }
}