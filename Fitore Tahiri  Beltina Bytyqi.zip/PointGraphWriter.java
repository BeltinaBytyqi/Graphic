import java.awt.*;
import javax.swing.*;

public class PointGraphWriter extends JPanel
{ JFrame grafiku = new JFrame();

   private int x1;  // Pozita e X1 ne grafik 
   private int y1;  //Pozita e Y1 ne grafik 
   private int x2;  // Pozita e X2 ne grafik 
   private int y2;  //Pozita e Y2 ne grafik  
   private int length; // Gjersia nga X1 deri tek "X2"
   private int x_pika; //distanca nga x deri te pika
   private int y_pika; 
   private int diameter;
   private String x_l;
   private String y_l;
   private int x1_pika; 
   private int y1_pika;
   private int x2_pika; 
   private int y2_pika;
   private int x3_pika; 
   private int y3_pika;
   private int x4_pika; 
   private int y4_pika;
   private int x5_pika; 
   private int y5_pika;
  

   public PointGraphWriter()
   { int gjeresia=600;
   
      grafiku.getContentPane().add(this);
      grafiku.setTitle("Grafiku");
      grafiku.setSize(gjeresia, gjeresia);
      grafiku.setVisible(true);
   }
/**paintComponent paints the panel
    * @param g - penda grafike qe vizaton pjeset e nevojshme */
   public void paintComponent(Graphics g)
   {
      x2= x1+length;
      y2=y1-length;
      diameter=5;
      int sip=600;
      x_pika= x1+(x1/6);
      x1_pika=x1+((2*x1)/6);
      x2_pika=x1+((3*x1)/6);
      x3_pika=x1+((4*x1)/6);
      x4_pika=x1+((5*x1)/6);
      x5_pika=x1+((6*x1)/6);
      
      g.setColor(Color.white);
      g.fillRect(0,0,sip,sip);
      g.setColor(Color.black);
      g.drawLine(x1,y1,x2,y1);
      g.drawLine(x1,y1,x1,y2);
      
      g.drawString(x_l, x2, y1+15);
      g.drawString(y_l,x1-15,y1-length);
      g.drawString("Ndryshimi i temperatures ne 6 javet e fundit." ,20,20);
      
      g.drawString("0",x1-15,y1);
      g.drawString("5",x1-15,y1-((length/6)));
      g.drawString("10",x1-15,y1-((2*length)/6));
      g.drawString("15",x1-15,y1-((3*length)/6));
      g.drawString("20",x1-15,y1-((4*length)/6));
      g.drawString("25",x1-15,y1-((5*length)/6));
      
      g.drawString("0", x1,y1+15);
      g.drawString("1", x1+(x1/6),y1+15);
      g.drawString("2", x1+((2*x1)/6),y1+15);
      g.drawString("3", x1+((3*x1)/6),y1+15);
      g.drawString("4", x1+((4*x1)/6),y1+15);
      g.drawString("5", x1+((5*x1)/6),y1+15);
      
      g.setColor(Color.red);
      g.fillOval(x1,y1,diameter ,diameter);
      g.fillOval(x_pika,y1-y_pika-5,diameter ,diameter);
      g.fillOval(x1_pika,y1-y1_pika-5,diameter ,diameter);
      g.fillOval(x2_pika,y1-y2_pika-5,diameter ,diameter);
      g.fillOval(x3_pika,y1-y3_pika-5,diameter ,diameter);
      g.fillOval(x4_pika,y1-y4_pika-5,diameter ,diameter);
      g.fillOval(x5_pika,y1-y5_pika-5,diameter ,diameter);
      
      g.setColor(Color.blue);
      g.drawLine(x1,y1,x_pika,y1-y_pika-2);
      g.drawLine(x_pika,y1-y_pika-2,x1_pika,y1-y1_pika-2);
      g.drawLine(x1_pika,y1-y1_pika-2,x2_pika,y1-y2_pika-2);
      g.drawLine(x2_pika,y1-y2_pika-2,x3_pika,y1-y3_pika-2);
      g.drawLine(x3_pika,y1-y3_pika-2,x4_pika,y1-y4_pika-2);
      g.drawLine(x4_pika,y1-y4_pika-2,x5_pika,y1-y5_pika-2);
      
      g.setColor(Color.black);
      g.fillOval(x1+(x1/6),y1,4 ,4);
      g.fillOval(x1+(2*x1/6),y1,4,4);
      g.fillOval(x1+(3*x1/6),y1,4,4);
      g.fillOval(x1+(4*x1/6),y1,4,4);
      g.fillOval(x1+(5*x1/6),y1,4,4);
      g.fillOval(x1+(6*x1/6),y1,4,4);
          
   }

   public void setAxes(int x_pos, int y_pos, int axis_length, String x_label, String y_label)
   {
      x1= x_pos;
      y1=y_pos;
      length= axis_length;
      x_l = x_label;
      y_l = y_label;   
   }

   public void setPoint1(int height)
   {  
      y_pika=height;
      x_pika =height+x1;
      this.repaint();
   }

   public void setPoint2(int height1)
   { 
      y1_pika=height1;
      x1_pika =height1+10+x1;
      this.repaint();
     
   }   
   
   public void setPoint3(int height2)
   {
      y2_pika=height2;
      x2_pika = height2+20+x1;
      this.repaint();
   }
   public void setPoint4(int height3)
   {
      y3_pika=height3;
      x3_pika = height3+30+x1;
      this.repaint();
   }
   public void setPoint5(int height4)
   {
      y4_pika =height4;
      x4_pika= height4+40+x1;
      this.repaint();
   }

   public void setPoint6(int height5)
   {
      y5_pika=height5;
      x5_pika = height5+50+x1;
      this.repaint();
   }
}
