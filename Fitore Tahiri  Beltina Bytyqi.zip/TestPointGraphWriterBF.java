public class TestPointGraphWriterBF{
   public static void main (String[] args){
     PointGraphWriterBF obj = new PointGraphWriterBF();
      obj.setAxes(200,250,200,"distanca","koha t");
      int o=3;
      obj.setPoint1((int)(BF.bf1(3,3)*o)); 
      obj.setPoint2((int)(BF.bf2(3,3)*o));
      obj.setPoint3((int)(BF.bf3(3,3)*o));
      obj.setPoint4((int)(BF.bf4(3,3)*o));
      obj.setPoint5((int)(BF.bf5(3,3)*o));
      obj.setPoint6((int)(BF.bf6(3,3)*o)); 
   }
}